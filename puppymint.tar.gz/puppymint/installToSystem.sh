#!/bin/bash

echo "start installation to system ..."

rm -rf /usr/local/puppymint 2>>/dev/null
mkdir /usr/local/puppymint 2>>/dev/null

cp -rf installationFolder /usr/local/puppymint
cp -rf run.sh /usr/local/puppymint

cat > /usr/local/bin/puppymint << EOF
#!/bin/bash
cd /usr/local/puppymint/
rm err.log 2>> err.log
defaultterminal -e ./run.sh
EOF

chmod 755 /usr/local/bin/puppymint

cat > /usr/share/applications/puppymint.desktop << EOF
[Desktop Entry]
Encoding=UTF-8
Name=PuppyMint
Icon=puppymint.svg
Comment=changes menu systems batch
Exec=puppymint
Terminal=false
Type=Application
Categories=Utility
GenericName=batch menu changer
NoDisplay=false
EOF

chmod 755 /usr/share/applications/puppymint.desktop

#read

fixmenus
jwm -restart