#!/bin/bash

echo start run...
cd installationFolder
rm err.log 2>> err.log
./InstallWithOptions.sh 2>>err.log
