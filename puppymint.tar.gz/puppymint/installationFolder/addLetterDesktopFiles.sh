#!/bin/bash

baseFolder=$(pwd)
cd /usr/share/applications
rm -f z_______*.desktop

for f in *.desktop
    do 

    name=$(grep 'Name=' $f | grep -v 'GenericName' | grep -v 'X-GNOME')

	resultofnodisplay=$(grep 'NoDisplay=' $f)

    #echo $name
    #echo $resultofnodisplay

    firstLetter=${name:5:1}
    capitalFirstLetter=${firstLetter^}
    underlined=$capitalFirstLetter" _________________________________"
    fileName="z_______$capitalFirstLetter.desktop"
    #echo $fileName
    
		if [ "$resultofnodisplay" == "NoDisplay=false" ]
		then
    
    #echo "not writing a file "$resultofnodisplay
cat > /usr/share/applications/$fileName << EOF
[Desktop Entry]
Encoding=UTF-8
Type=Application
Icon=folder48.png
NoDisplay=false
Name=$underlined
Exec=
EOF
		fi
    done

cd $baseFolder