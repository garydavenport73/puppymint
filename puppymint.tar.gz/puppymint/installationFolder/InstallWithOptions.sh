#!/bin/bash

#make a folder structure that contains puppy linux contents
baseFolder=$(pwd)
myEditor=leafpad

isLoopDone="false"
while [ "$isLoopDone" == "false" ]
do
	echo " "
	echo "Would you like to watch what is happening"
	echo "with the ability to modify the process?"
	echo "1. Quiet - just proceed."
	echo "2. Watch - modify if needed."

	read yourResponse
	if [ "$yourResponse" == "1" ]
	then
		#your code here
		watchProcess="false"
		isLoopDone="true"
	elif [ "$yourResponse" == "2" ]
	then
		#your code here
		watchProcess="true"
		isLoopDone="true"
	else
		#your code here
		isLoopDone="false"
	fi
done

mkdir puppy
cd puppy

mkdir _root_dotjwmrc 									
cp -n /etc/xdg/templates/_root_.jwmrc _root_dotjwmrc/ 	

mkdir dotjwmrc-tray 									
cp -n /root/.jwmrc-tray dotjwmrc-tray 					

mkdir jwmrc-trays 										
cp -n /root/.jwm/jwmrc-tray* jwmrc-trays 				

mkdir jwmrc-personal									
cp -n /root/.jwm/jwmrc-personal jwmrc-personal			

mkdir wallpaper											
cp -n /root/.config/wallpaper/* wallpaper				

if [ -f wallpaper/bg_img ]; then
   #your code here
   read -r backgroundFilename<wallpaper/bg_img
else
   #your code here
   #echo "File wallpaper/bg_img does not exist, making"
   backgroundFilename="/usr/share/backgrounds/default.png"
   cat > wallpaper/bg_img << EOF
/usr/share/backgrounds/default.png
EOF
fi

mkdir background
cp -n "$backgroundFilename" background

mkdir applicationsShow
mkdir configuration
mkdir nameChangeList

cd ../

rm -rf recent
mkdir recent
cd recent

mkdir _root_dotjwmrc
cp /etc/xdg/templates/_root_.jwmrc _root_dotjwmrc/

mkdir dotjwmrc-tray
cp /root/.jwmrc-tray dotjwmrc-tray

mkdir jwmrc-trays
cp /root/.jwm/jwmrc-tray* jwmrc-trays

mkdir jwmrc-personal
cp /root/.jwm/jwmrc-personal jwmrc-personal

mkdir wallpaper
cp /root/.config/wallpaper/* wallpaper

if [ -f wallpaper/bg_img ]; then
   #your code here
   read -r backgroundFilename<wallpaper/bg_img
else
   #your code here
   #echo "File wallpaper/bg_img does not exist, making"
   backgroundFilename="/usr/share/backgrounds/default.png"
   cat > wallpaper/bg_img << EOF
/usr/share/backgrounds/default.png
EOF
fi

mkdir background
cp "$backgroundFilename" background

mkdir applicationsShow
mkdir configuration
mkdir nameChangeList

cd ../

#make list of applications
ls /usr/share/applications/*.desktop > applicationsList.txt

#collect information and make a configuration sheet, also adds noDisplay to true
#or false in each .desktop file, collect info on what .desktop files are being shown
# and make a list of name change list that can be altered
python collectApplicationData.py

python makeApplicationsShowNoAsk.py

python makeNameChangeList.py

cp -n configuration.txt puppy/configuration
cp -n applicationsShow.txt puppy/applicationsShow
cp -n nameChangeList.txt puppy/nameChangeList

cp configuration.txt recent/configuration
cp applicationsShow.txt recent/applicationsShow
cp nameChangeList.txt recent/nameChangeList

rm -f configuration.txt
rm -f originalConfiguration.json
rm -f applicationsShow.txt
rm -f nameChangeList.txt

rm -rf temp
mkdir temp

addLetterDesktopFiles="false"
runAddCategories="false"

isLoopDone="false"
while [ "$isLoopDone" == "false" ]
do
  echo " "
  echo "Switch to:"
  echo "1. First Backup"
  echo "2. Linux Mint"
  echo "3. Windows"
  echo "4. Custom"
  echo "5. Interactive"
  read yourResponse
  if [ "$yourResponse" == "1" ]
  then
      cp -rf puppy/* temp
      #your code here
      isLoopDone="true"
  elif [ "$yourResponse" == "2" ]
  then
      #your code here
        runAddCategories="true"
        isLoopDone="false"
            while [ "$isLoopDone" == "false" ]
            do
                echo "Installing to:"
                echo "1. Bionic or Similar Pup"
                echo "2. Xenial, FossaPup or Similar Pup"
                read yourResponse
                if [ "$yourResponse" == "1" ]
                then
                    #your code here
                    cp -rf mintbionic/* temp
                    isLoopDone="true"
                elif [ "$yourResponse" == "2" ]
                then
                    #your code here
                    cp -rf mintxenial/* temp
                    isLoopDone="true"
                else
                    #your code here
                    isLoopDone="false"
                fi
            done

            #echo "Press enter to continue."
            #read
      isLoopDone="true"
  elif [ "$yourResponse" == "3" ]
  then
      #your code here
        addLetterDesktopFiles="true"
        isLoopDone="false"
            while [ "$isLoopDone" == "false" ]
            do
				echo " "
                echo "Installing to:"
                echo "1. Bionic or Similar Pup"
                echo "2. Xenial, FossaPup or Similar Pup"
                read yourResponse
                if [ "$yourResponse" == "1" ]
                then
                    #your code here
                    cp -rf wyndowsbionic/* temp
                    isLoopDone="true"
                elif [ "$yourResponse" == "2" ]
                then
                    #your code here
                    cp -rf wyndowsxenial/* temp
                    isLoopDone="true"
                else
                    #your code here
                    isLoopDone="false"
                fi
            done
            #echo "Press enter to continue."
            #read
      isLoopDone="true"
  elif [ "$yourResponse" == "4" ]
  then
      #your code here
      cp -rf custom/* temp
      isLoopDone="true"
  elif [ "$yourResponse" == "5" ]
  then
      cp -rf recent/* temp
			#see if user wants to rename applications
            isLoopDone="false"
            while [ "$isLoopDone" == "false" ]
            do
				echo " "
                echo "Rename your applications?:"
                echo "1. Yes"
                echo "2. No"
                read yourResponse
                if [ "$yourResponse" == "1" ]
                then
                    #your code here
                    $myEditor temp/nameChangeList/nameChangeList.txt
                    cp temp/nameChangeList/nameChangeList.txt ./
                    cp temp/configuration/configuration.txt ./
                    python renameApplications.py
                    cp nameChangeList.txt temp/nameChangeList/
                    cp configuration.txt temp/configuration/
                    rm nameChangeList.txt
                    rm configuration.txt
                    #python reorderApplications.py
                    #python makeApplicationsShowNoAsk.py
                    isLoopDone="true"
                elif [ "$yourResponse" == "2" ]
                then
                    #your code here
                    isLoopDone="true"
                else
                    #your code here
                    isLoopDone="false"
                fi
            done
            #echo "Press enter to continue."
            #read
            
			#see if user wants to pick which applications to show            
            isLoopDone="false"
            while [ "$isLoopDone" == "false" ]
            do
                echo " " 
                echo "Pick which applications to show?:"
                echo "1. Yes"
                echo "2. No"
                read yourResponse
                if [ "$yourResponse" == "1" ]
                then
                    #your code here
                    cp temp/configuration/configuration.txt ./
                    
                    python reorderApplications.py
                    python makeApplicationsShowNoAsk.py
                    $myEditor applicationsShow.txt
                    
                    cp applicationsShow.txt temp/applicationsShow/
                    cp configuration.txt temp/configuration/
					
					rm applicationsShow.txt
					rm configuration.txt
					
                    isLoopDone="true"
                elif [ "$yourResponse" == "2" ]
                then
                    #your code here
                    isLoopDone="true"
                else
                    #your code here
                    isLoopDone="false"
                fi
            done

            #echo "Press enter to continue."
            #read
            
            
			#see if user wants to pick a menu system            
            isLoopDone="false"
            while [ "$isLoopDone" == "false" ]
            do
				echo " "
				echo "Would you like to pick a menu system"
				echo "1. No, keep the same"
				echo "2. Linux Mint"
				echo "3. Wyndows/Alphabetical"
                read yourResponse
                if [ "$yourResponse" == "1" ]
                then
                    #your code here
                    isLoopDone="true"
                elif [ "$yourResponse" == "2" ]
                then
                    #your code here
                    # Linux Mint stuff
					isLoopDone="false"
					while [ "$isLoopDone" == "false" ]
					do
						echo " "
						echo "Installing to:"
						echo "1. Bionic or Similar Pup"
						echo "2. Xenial, FossaPup or Similar Pup"
						read yourResponse
						if [ "$yourResponse" == "1" ]
						then
							#your code here
							cp -rf mintbionic/desktop-directories temp
							cp -rf mintbionic/menus temp
							cp -rf mintbionic/menuIcons temp
							
							cp -rf mintbionic/jwmrc-trays temp
							cp -rf mintbionic/_root_dotjwmrc/ temp

							
							isLoopDone="true"
						elif [ "$yourResponse" == "2" ]
						then
							#your code here
							cp -rf mintxenial/desktop-directories temp
							cp -rf mintxenial/menus temp
							cp -rf mintxenial/menuIcons temp
							
							cp -rf mintxenial/dotjwmrc-tray/ temp
							cp -rf mintxenial/jwmrc-personal/ temp
							cp -rf mintxenial/_root_dotjwmrc/ temp
							
							isLoopDone="true"
						else
						#your code here
							isLoopDone="false"
						fi
					done
                    isLoopDone="true"
                elif [ "$yourResponse" == "3" ]
                then
                    #your code here
                    # Windows stuff
					isLoopDone="false"
					while [ "$isLoopDone" == "false" ]
					do
						echo " "
						echo "Installing to:"
						echo "1. Bionic or Similar Pup"
						echo "2. Xenial, FossaPup or Similar Pup"
						read yourResponse
						if [ "$yourResponse" == "1" ]
						then
							#your code here
							cp -rf wyndowsbionic/desktop-directories/ temp
							cp -rf wyndowsbionic/menus/ temp
							cp -rf wyndowsbionic/jwmrc-trays/ temp
							cp -rf wyndowsbionic/_root_dotjwmrc/ temp
							isLoopDone="true"
						elif [ "$yourResponse" == "2" ]
						then
							#your code here
							cp -rf wyndowsxenial/desktop-directories/ temp
							cp -rf wyndowsxenial/menus/ temp
							cp -rf wyndowsxenial/dotjwmrc-tray/ temp
							cp -rf wyndowsxenial/jwmrc-personal/ temp
							cp -rf wyndowsbionic/_root_dotjwmrc/ temp
							isLoopDone="true"
						else
						#your code here
							isLoopDone="false"
						fi
					done
					# check to see if user wants to add alphabetical marker
					isLoopDone="false"
					while [ "$isLoopDone" == "false" ]
					do
						echo " "
						echo "Do you want to add alphabetical markers to your"
						echo "Menuing system.  This is recommended for"
						echo "Wyndows/alphabetical menuing system."
						echo 
						echo "1. Yes (usually for Wyndows Menu)"
						echo "2. No"
						read yourResponse
						if [ "$yourResponse" == "1" ]
						then
							#your code here
							addLetterDesktopFiles="true"
							isLoopDone="true"
						elif [ "$yourResponse" == "2" ]
						then
							#your code here
							addLetterDesktopFiles="false"
							isLoopDone="true"
						else
						#your code here
							isLoopDone="false"
						fi
					done
                    isLoopDone="true"
                else
                    #your code here
                    isLoopDone="false"
                fi
            done

            #echo "Press enter to continue."
            #read
            
			#see if user wants to add categories
            isLoopDone="false"
            while [ "$isLoopDone" == "false" ]
            do
				echo " "
                echo "Would you like to add standard program categories"
                echo "to puppy program categories?"
                echo " "
                echo "This is highly recommended if you are using Linux Mint"
                echo "or other non-puppy menu systems."
                echo "This is because other menu systems may not recognize puppy"
                echo "categories and lump your applications in to the 'other' category."
                echo " "
                echo "1. Add standard categories (Linux Mint or Similar)."
                echo "2. Don't add (Wyndows is alphabetical listing, not grouped by category)."
                read yourResponse
                if [ "$yourResponse" == "1" ]
                then
                    #your code here
                    runAddCategories="true"
                    cp -rf mintbionic/addCategoriesList temp
                    $myEditor temp/addCategoriesList/addCategoriesList.txt
                    isLoopDone="true"
                elif [ "$yourResponse" == "2" ]
                then
                    #your code here
                    isLoopDone="true"
                else
                    #your code here
                    isLoopDone="false"
                fi
            done
            #echo "Press enter to continue."
            #read            
            
			#see if user wants to change backgrounds
            isLoopDone="false"
            while [ "$isLoopDone" == "false" ]
            do
				echo " "
                echo "Change backgrounds?:"
                echo "1. Puppy"
                echo "2. Linux Mint."
                echo "3. Wyndows."
                echo "4. No change."
                read yourResponse
                if [ "$yourResponse" == "1" ]
                then
                    #your code here
                    rm -rf temp/background
                    rm -rf temp/background
                    cp -rf puppy/background temp
                    cp -rf puppy/wallpaper temp
                    isLoopDone="true"
                elif [ "$yourResponse" == "2" ]
                then
                    #your code here
                    rm -rf temp/background
                    rm -rf temp/background
                    cp -rf mintbionic/background temp
                    cp -rf mintbionic/wallpaper temp
                    isLoopDone="true"
                elif [ "$yourResponse" == "3" ]
                then
                    #your code here
                    rm -rf temp/background
                    rm -rf temp/background
                    cp -rf wyndowsbionic/background temp
                    cp -rf wyndowsbionic/wallpaper temp
                    isLoopDone="true"
                elif [ "$yourResponse" == "4" ]
                then
                    #your code here
                    isLoopDone="true"
                else
                    #your code here
                    isLoopDone="false"
                fi
            done
            #echo "Press enter to continue."
            #read  

			# theme icons
			
      isLoopDone="true"
  else
      #your chode here
      isLoopDone="false"
  fi
done
#echo "Press enter to continue:"

#read


# MAIN PROCESSING
# work everything out of temp directory

cp temp/addCategoriesList/addCategoriesList.txt ./
cp temp/applicationsShow/applicationsShow.txt ./
cp temp/configuration/configuration.txt ./
cp temp/nameChangeList/nameChangeList.txt ./

cp -rf temp/desktop-directories/* /usr/share/desktop-directories/
cp -rf ./temp/dotjwmrc-tray/.jwmrc-tray /root/
cp -rf ./temp/jwmrc-trays/* /root/.jwm/
cp -f temp/jwmrc-personal/* /root/.jwm/
mkdir /usr/share/icons/hicolor/48x48/apps
cp -f temp/menuIcons/* /usr/share/icons/hicolor/48x48/apps
cp -f temp/menus/* /etc/xdg/menus/
cp -f temp/_root_dotjwmrc/_root_.jwmrc /etc/xdg/templates/
cp -rf temp/themes/* /usr/local/lib/X11/themes/
cp -rf temp/background/* temp/background/default.png
cp -rf temp/background/default.png /usr/share/backgrounds/
cp -rf temp/wallpaper/bg_img /root/.config/wallpaper/

if [ $watchProcess == "true" ]
then
$myEditor nameChangeList.txt
fi

python renameApplications.py
python reorderApplications.py
python makeApplicationsShowNoAsk.py

if [ $watchProcess == "true" ]
then
$myEditor applicationsShow.txt
fi

python hideAllApplications.py
python showApplications.py
python reorderApplications.py

if [ $runAddCategories == "true" ]
then

	if [ $watchProcess == "true" ]
	then
		$myEditor addCategoriesList.txt
	fi

### put another nest if to show the add categories document
python addCategories.py # only for mint or custom

fi

if [ $watchProcess == "true" ]
then
$myEditor configuration.txt
fi

echo " "
echo "Press enter to process, or control-c to abort."

read

python processConfiguration.py

mkdir interactive
cp -rf temp interactive
cp -f applicationsShow.txt interactive/applicationsShow
cp -f configuration.txts interactive/configuration
cp -f nameChangeList.txt interactive/nameChangeList
cp -f applicationsList.txt interactive/applicationsList
cp -f addCategoriesList.txt interactive/addCategories
cp -f configuration.txt interactive/configuration

rm -f applicationsShow.txt
rm -f configuration.txts
rm -f nameChangeList.txt
rm -f applicationsList.txt
rm -f addCategoriesList.txt
rm -f configuration.txt
rm -rf temp

if [ $addLetterDesktopFiles == "true" ]
then
./addLetterDesktopFiles.sh
else
rm -f /usr/share/applications/z_______*.desktop
fi
echo " "
echo "Please wait awhile ..."

fixmenus
jwm -restart
restartwm
