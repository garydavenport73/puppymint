#!/bin/bash

rm -rf interactive
rm -rf puppy
rm -rf recent
