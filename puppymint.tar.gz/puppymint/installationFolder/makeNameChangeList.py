try: input = raw_input
except NameError: raw_input = input
# Read configuration file
try:
    infile = open("configuration.txt","r")
    lines=infile.readlines()
    infile.close()
    allData=[]
    for j in range(len(lines)):
        data = lines[j].split(",")
        for i in range(len(data)):
            data[i] = data[i].strip()
        allData.append(data)
        #print(data)
except:
    print("configuration.txt not found in current folder.  Exiting")
    raw_input("\nPress any key to exit")
    exit()


#print("nameChangeList.txt not found in current folder, writing one.")
#need to put here code to write names to the file
numberOfspaces3 = ' ' * (40-len("Current Name of Your Application"))
str2= "Current Name of Your Application" + "," + numberOfspaces3 + "The Name You Want\n" 
str2+="--------------------------------" + "," + numberOfspaces3 + "-----------------\n"
for data in allData:
    numberOfspaces3 = ' ' * (40-len(data[1]))
    if len(data)>1:# make sure at least 2 list entries
        str2+=data[1]+","+numberOfspaces3+data[1]+"\n";

#print(str2)
outfile=open("nameChangeList.txt","w")
outfile.write(str2)
outfile.close()
    
#raw_input("Press enter to continue.")

