try: input = raw_input
except NameError: raw_input = input
# Read configuration file
try:
    infile = open("configuration.txt","r")
    lines=infile.readlines()
    infile.close()
    allData=[]
    for j in range(len(lines)):
        data = lines[j].split(",")
        for i in range(len(data)):
            data[i] = data[i].strip()
        allData.append(data)
        #print(data)

except:
    print("configuration.txt not found in current folder.  Exiting")
    raw_input("\nPress any key to exit")
    exit()

#define key to sort by
def keyValuesValue(dataLine):
    return dataLine[1].lower()

allData.sort(key=keyValuesValue)

str1=""
for data in allData:
    if data[0]=="true":
        numberOfspaces = ' ' * (40-len(data[1]))
        numberOfspaces2 = ' ' * (40-len(data[2]))
        str1+=data[0]+",\t"+data[1]+","+numberOfspaces+"\t"+data[2]+","+numberOfspaces2+"\t"+data[3]+"\n"
for data in allData:
    if data[0]=="false":
        numberOfspaces = ' ' * (40-len(data[1]))
        numberOfspaces2 = ' ' * (40-len(data[2]))
        str1+=data[0]+",\t"+data[1]+","+numberOfspaces+"\t"+data[2]+","+numberOfspaces2+"\t"+data[3]+"\n"  
outfile=open("configuration.txt","w")
outfile.write(str1)
outfile.close()
#raw_input("reorderApplications.py finished.")
