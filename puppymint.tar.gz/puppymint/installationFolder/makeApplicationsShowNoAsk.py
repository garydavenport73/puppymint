try: input = raw_input
except NameError: raw_input = input
# look to see if applicationShow exists, if it does not make
# one from the configuration file

def doesExist(filename):
    try:
        infile=open(filename,"r")
        infile.close()
        return True
    except:
        print(filename+" not found.")
        return False

def writeFile():
    if doesExist("configuration.txt")==True:
        infile = open("configuration.txt","r")
        lines=infile.readlines()
        infile.close()
        allData=[]
        for j in range(len(lines)):
            data = lines[j].split(",")
            for i in range(len(data)):
                data[i] = data[i].strip()
            allData.append(data)
            #print(data)
    else:
        print("configuration.txt not found in current folder.  Exiting")
        raw_input("\nPress any key to exit")
        exit()
    #print("writing applicationsShow.txt")
    outfile=open("applicationsShow.txt","w")
    outfile.write("Delete any programs you don't want to show in menu.\n")
    outfile.write("---------------------------------------------------\n")
    for data in allData:
        #print(data[1])
        if data[0]=="true": outfile.write(data[1]+"\n")
    outfile.close()

writeFile()
