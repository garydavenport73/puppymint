try: input = raw_input
except NameError: raw_input = input


try:
    infile = open("configuration.txt", "r")
    allLines=infile.read()
    infile.close()
except:
    print("configuration.txt not found in current folder.  Exiting")
    #raw_input("\nPress any key to exit")
    exit()

lines=allLines.split('\n')

# go through each file listed on each line
for j in range(len(lines)):
    data = lines[j].split(",")
    for i in range(len(data)):
        data[i] = data[i].strip()
    # print(data)
    displayStatus = data[0]
    if displayStatus == "false":
        noDisplayStatus = "true"
    else:
        noDisplayStatus = "false"
    if len(data)>=2:name = data[1]
    if len(data)>=3:categories = data[2]
    if len(data)>=4:path=data[3]
    # go through each file and make a mirror copy, but replace name and display lines with data
    stringToWrite = ""
    try:
        infile2 = open(path, "r")
        isDisplayStatusAlreadyPresent = False
        isCategoriesAlreadyPresent = False
        for line2 in infile2:
            pass
            if line2.strip()[0:5] == "Name=":  # found line with name
                stringToWrite += "Name="+name+"\n"
            elif line2.strip()[0:10] == "NoDisplay=":  # found line with display status
                stringToWrite += "NoDisplay="+noDisplayStatus+"\n"
                isDisplayStatusAlreadyPresent = True
            elif line2.strip()[0:11] == "Categories=":  # found line with Categories 
                isCategoriesAlreadyPresent=True
                if categories!="":
                    stringToWrite += "Categories="+categories+"\n"
                else:
                    stringToWrite += line2.strip()+"\n"
            else:
                stringToWrite += line2
        if isDisplayStatusAlreadyPresent == False:
            stringToWrite += "NoDisplay="+noDisplayStatus+"\n"
        if isCategoriesAlreadyPresent == False:
            #raw_input("no category found")
            if categories!="":stringToWrite += "Categories="+categories+"\n"
        infile2.close()
    except:
        print(path+" not found.")
    #print(stringToWrite)
    #print("*******")
    try:
        outfile = open(path, "w")
        outfile.write(stringToWrite)
        outfile.close()
    except:
        print("Could not open "+path+" to write "+name)

#raw_input("Press enter to continue.")
