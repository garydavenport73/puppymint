try: input = raw_input
except NameError: raw_input = input
# Read configuration file
try:
    infile = open("configuration.txt","r")
    lines=infile.readlines()
    infile.close()
    allData=[]
    for j in range(len(lines)):
        data = lines[j].split(",")
        for i in range(len(data)):
            data[i] = data[i].strip()
        allData.append(data)
        #print(data)
except:
    print("configuration.txt not found in current folder.  Exiting")
    #raw_input("\nPress any key to exit")
    exit()

try:
    # read name change list
    infile = open("addCategoriesList.txt","r")
    lines2=infile.readlines()
    infile.close()
    categoriesData=[]
    for j in range(len(lines2)):
        data2 = lines2[j].split(",")
        for i in range(len(data2)):
            data2[i] = data2[i].strip()
        categoriesData.append(data2)
        #print(data2)
except:
    print("addCategoriesList.txt not found in current folder.")
    #raw_input("\nPress any key to exit.")
    exit()

# go through each line of data in the configuration file
# split the categories into a list for each line puppy list puppycategories
# go through each categories in the puppy list puppycategory
# go through each line in the key value data
# see if the puppy category matches the key 
# if it matches the key, append the value to puppycategories

# delete duplicate entries in puppycategories and empty strings

foundCount=0
# go through each line of data in the configuration file
for data in allData:
    # split the categories into a list for each line puppy list puppycategories
    puppyCategories=data[2].split(";")
    # go through each categories in the puppy list puppycategory
    for puppycategory in puppyCategories:
        puppycategory=puppycategory.strip()
        # go through each line in the key value data
        for categories in categoriesData:
            if len(categories)>1:# make sure someone entered at least 2 names
                # see if the puppy category matches the key 
                if puppycategory==categories[0]:
                    # if it matches the key, append the value to puppycategories
                    #print("MATCH FOUND!!!")
                    #print(puppycategory,categories[0])
                    #print(puppyCategories)
                    puppyCategories.append(categories[1])
                    #print(puppyCategories)

    #print(puppyCategories)
    #remove empty strings
    while ("" in puppyCategories):
        puppyCategories.remove("")
    #remove duplicate entries in puppy categories
    #print("-------removing duplicates-------")
    puppyCategoriesSet = set(puppyCategories)
    puppyCategories=list(puppyCategoriesSet)
    #print(puppyCategories)

    #join puppy categories into a string with ;
    newCategoriesString=";".join(puppyCategories)
    #print(newCategoriesString)
    data[2]=newCategoriesString

str1=""
for data in allData:
    #print(data[0],data[1])
    #print(data[0]+","+data[1]+","+data[2]+","+data[3]+"\n")
    numberOfspaces = ' ' * (40-len(data[1]))
    numberOfspaces2 = ' ' * (40-len(data[2]))
    str1+=data[0]+",\t"+data[1]+","+numberOfspaces+"\t"+data[2]+","+numberOfspaces2+"\t"+data[3]+"\n"

outfile=open("configuration.txt","w")
outfile.write(str1)
outfile.close()

#raw_input("Press enter to continue.")

