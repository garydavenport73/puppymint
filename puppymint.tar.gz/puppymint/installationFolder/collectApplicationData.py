try: input = raw_input
except NameError: raw_input = input
infile = open("applicationsList.txt", "r")

stringToWrite = ""
categories = ""
dictionaryOfFilesInfo = {}
fileInfoArray=[]

for line in infile:

    fileName = line.strip()
    # print(fileName)
    try:
        infile2 = open(fileName, 'r')
        noDisplayStatus = ""
        displayStatus = ""
        categories=""
        for line2 in infile2:
            if line2.strip()[0:5] == "Name=":
                applicationName = line2.strip()[5:]
            elif line2.strip()[0:10] == "NoDisplay=" and noDisplayStatus == "":
                noDisplayStatus = line2.strip()[10:]
            elif line2.strip()[0:11] == "Categories=":
                categories = line2.strip()[11:]
            else:
                pass
        if noDisplayStatus == "":
            noDisplayStatus = "false"

        numberOfspaces = ' ' * ((40-len(applicationName)+1))
        numberOfspaces2 = ' ' * ((48-len(categories)+1))
        # print(noDisplayStatus+",\t"+applicationName+","+numberOfTabs+fileName)
        if noDisplayStatus == "true":
            displayStatus = "false"
        else:
            displayStatus = "true"
        
        stringToWrite += displayStatus+",\t"+applicationName+"," +         numberOfspaces+"\t"+categories+","+numberOfspaces2+"\t"+fileName+"\n"

        dictionaryOfFilesInfo[fileName] = [
            displayStatus, applicationName, categories]

        infile2.close()
    except:
        print("file-> "+fileName +" not found.")

infile.close()


#make dictionary into list, so it can be sorted(indexed)
filesList=list(dictionaryOfFilesInfo.items())

#define key to sort by
def keyValuesValue(filesListMember):
    return filesListMember[1][1].lower()

filesList.sort(key=keyValuesValue)

#list is already alphabetical, show trues first, then false next
stringToWrite=""
for i in range(len(filesList)):
    if filesList[i][1][0]=="true":
        numberOfspaces = ' ' * ((40-len(filesList[i][1][1])+1))
        numberOfspaces2 = ' ' * ((48-len(filesList[i][1][2])+1))
        stringToWrite += filesList[i][1][0]+",\t"+filesList[i][1][1]+"," + numberOfspaces+"\t"+filesList[i][1][2]+","+numberOfspaces2+"\t"+filesList[i][0]+"\n"
for i in range(len(filesList)):
    if filesList[i][1][0]=="false":
        numberOfspaces = ' ' * ((40-len(filesList[i][1][1])+1))
        numberOfspaces2 = ' ' * ((48-len(filesList[i][1][2])+1))
        stringToWrite += filesList[i][1][0]+",\t"+filesList[i][1][1]+"," + numberOfspaces+"\t"+filesList[i][1][2]+","+numberOfspaces2+"\t"+filesList[i][0]+"\n"

#print(stringToWrite)

try:   
    outfile = open("configuration.txt", "w")
    outfile.write(stringToWrite)
    outfile.close()
    #print("wrote configuration")
except:
    print("could not write configuration.txt")
    """outfile = open("configuration.txt", "w")
    outfile.write(stringToWrite)
    #print("congifuration.txt")
    #print(stringToWrite)
    outfile.close()
    """
dictionaryOfFilesInfo = {}
for i in range(len(filesList)):
    if filesList[i][1][0]=="true":
        dictionaryOfFilesInfo[filesList[i][0]] = [filesList[i][1][0], filesList[i][1][1], filesList[i][1][2]]
for i in range(len(filesList)):
    if filesList[i][1][0]=="false":
        dictionaryOfFilesInfo[filesList[i][0]] = [filesList[i][1][0], filesList[i][1][1], filesList[i][1][2]]

try:
    testfile = open("originalConfiguration.json", "r")
    print("file already exists, not writing originalConfiguration.json")
    testfile.close()
except:
    outfile = open("originalConfiguration.json", "w")
    outfile.write(str(dictionaryOfFilesInfo).replace("\'", "\""))
    outfile.close()
    #print("originalConfiguration.json")
#raw_input("Press enter to continue.")
