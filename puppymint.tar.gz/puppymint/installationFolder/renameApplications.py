try: input = raw_input
except NameError: raw_input = input
# Read configuration file
try:
    infile = open("configuration.txt","r")
    lines=infile.readlines()
    infile.close()
    allData=[]
    for j in range(len(lines)):
        data = lines[j].split(",")
        for i in range(len(data)):
            data[i] = data[i].strip()
        allData.append(data)
        #print(data)
except:
    print("configuration.txt not found in current folder.  Exiting")
    raw_input("\nPress any key to exit")
    exit()

try:
    # read name change list
    infile = open("nameChangeList.txt","r")
    lines2=infile.readlines()
    infile.close()
    nameData=[]
    for j in range(len(lines2)):
        data2 = lines2[j].split(",")
        for i in range(len(data2)):
            data2[i] = data2[i].strip()
        nameData.append(data2)
        #print(data2)
except:
    print("nameChangeList.txt not found in current folder.")
    raw_input("\nPress any key to exit.")
    exit()
    
# look for names in data file
# if found, replace names with value
# the way it is done in this case is to 
# set the first array value to key and second to value
# ie first is input name, second is output name
foundCount=0
for data in allData:
    for name in nameData:
        if len(name)>1:# make sure someone entered at least 2 names
            if name[0]==data[1]:
                data[1]=name[1]
                foundCount+=1
                #print("found one",name[0],name[1])
str1=""
for data in allData:
    #print(data[0],data[1])
    #print(data[0]+","+data[1]+","+data[2]+","+data[3]+"\n")
    numberOfspaces = ' ' * (40-len(data[1]))
    numberOfspaces2 = ' ' * (40-len(data[2]))
    str1+=data[0]+",\t"+data[1]+","+numberOfspaces+"\t"+data[2]+","+numberOfspaces2+"\t"+data[3]+"\n"

outfile=open("configuration.txt","w")
outfile.write(str1)
outfile.close()

#raw_input("renameApplications.py completed.")

